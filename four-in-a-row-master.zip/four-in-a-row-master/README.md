# Four In A Row assignment AI: Principles & Techniques

